# mlops


streamlit
1. Create a Streamlit Application for Visualizing CSV Data: https://csvvisualizer.streamlit.app/
2. Create a Streamlit Application for Displaying Weather Information: https://weatherappassignment.streamlit.app/
3. Create a Streamlit Application for Basic Sentiment Analysis: https://mlopsassignmentemotion.streamlit.app/
